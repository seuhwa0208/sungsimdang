package com.sungsimdang.project.board.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NoticeRequest {

    @NotBlank
    private String title;

    @NotBlank
    private String content;
}
