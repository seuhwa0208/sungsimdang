package com.sungsimdang.project.board.service;

import com.sungsimdang.project.board.Qna;
import com.sungsimdang.project.board.dto.QnaRequest;
import com.sungsimdang.project.board.dto.QnaResponse;
import com.sungsimdang.project.board.repository.QnaRepository;
import com.sungsimdang.project.member.domain.Member;
import com.sungsimdang.project.member.repository.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class QnaService {
    private final QnaRepository qnaRepository;
    private final MemberRepository memberRepository;

    //전체 질문 및 답변의 목록
    public List<Qna> findAll() {
        return qnaRepository.findAllByOrderByCreatedAtDesc();
    }
    //특정 회원의 질문 및 답변 목록
    public List<Qna> findById(Long memberId) {
        return qnaRepository.findByMemberIdOrderByCreatedAtDesc(memberId);
    }
    //질문 및 답변 상세보기 - 옵셔널 처리
    public Qna detail(Long id) {
        return qnaRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("해당 Q&A를 찾지 못 했습니다."));
    }
    //질문 등록 - 회원만 가능하므로 회원인지 여부부터 판단
    @Transactional
    public Qna create(Long memberId, QnaRequest request) {
        Member member = getMember(memberId);

        return QnaResponse.from(qnaRepository.save(member));
    }
    //자신이 작성하거나 관리자만 질문 수정하기

    //자신이 작성한 질문이거나 관리자만 삭제하기

    //답변하기(관리자만)

    //답변 수정(관리자만)

    //답변 삭제(관리자만)

    //회원 여부 판단 - 옵셔널 처리
    public Member getMember(Long memberId) {
        return memberRepository.findById(memberId).orElseThrow(() -> new IllegalArgumentException("회원을 찾을 수 없습니다."));
    }
    //관리자 계정 여부 판단

    //본인이 작성한 Qna이거나 관리자인지 여부 판단

    //빈 값 또는 널 여부 판단

}
